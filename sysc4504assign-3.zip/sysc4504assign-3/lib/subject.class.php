<?php

require_once('art-config.php');

define('SUBJECTS_BY_ARTWORK_ID',
		'SELECT * FROM Subjects
		INNER JOIN ArtworkSubjects ON ArtworkSubjects.SubjectID = Subjects.SubjectID WHERE ArtworkSubjects.ArtworkID = :id;');

class Subject {
	public $SubjectID;
	public $SubjectName;
}

function loadSubjects($artworkId) {
	try {
		$pdo = new PDO(DBCONNSTR, DBUSER, DBPASS);
		$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		$sql = SUBJECTS_BY_ARTWORK_ID;
		$statement = $pdo->prepare($sql);
		$statement->bindValue(':id', $artworkId);
		$statement->execute();
		
		$subjects = array();
		
		while($subject = $statement->fetchObject('Genre')) {
			$subjects[] = $subject;
		}
		$pdo = null;
		return $subjects;
	} catch (PDOException $e) {
		die($e->getMessage());
	}
}

function printAllSubjects($subjects) {
	$i = 0;
	for (; $i < count($subjects) - 1; $i++) {
		printf("%s, ", $subjects[$i]->SubjectName);
	}
	printf("%s", $subjects[$i]->SubjectName);
}

?>