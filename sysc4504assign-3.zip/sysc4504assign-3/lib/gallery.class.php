<?php

require_once('art-config.php');

define('GALLERY_LOCATIONS_BY_ARTWORKID',
		'SELECT Galleries.GalleryID, GalleryName, GalleryCity, GalleryCountry, GalleryWebSite FROM Galleries
		INNER JOIN Artworks ON Artworks.GalleryID = Galleries.GalleryID WHERE ArtworkID = :id;');

class Gallery {
	public $GalleryID;
	public $GalleryName;
	public $GalleryCity;
	public $GalleryCountry;
	public $GalleryWebSite;
	
	function getLocation() {
		if ($this->GalleryCity === null) {
			return $this->GalleryName;
		}
		return sprintf("%s, %s, %s", $this->GalleryName, $this->GalleryCity, $this->GalleryCountry);
	}
	
	function getLink() {
		if ($this->GalleryCity === null) {
			return $this->GalleryName;
		}
		return sprintf('<a href="%s">%s</a>', $this->GalleryWebSite, $this->getLocation());
	}
}

function loadGallery($artworkID) {
	try {
		$pdo = new PDO(DBCONNSTR, DBUSER, DBPASS);
		$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		$sql = GALLERY_LOCATIONS_BY_ARTWORKID;
		$statement = $pdo->prepare($sql);
		$statement->bindValue(':id', $artworkID);
		$statement->execute();
		
		$gallery = $statement->fetchObject('Gallery');
		$pdo = null;
		return $gallery;
	} catch (PDOException $e) {
		die($e->getMessage());
	}
}