<?php

    require_once('art-config.php');
    
    define('ARTIST_BY_ID', 'SELECT * FROM Artists WHERE ArtistID = :id;');

    class Artist {
        public $ArtistID;
        public $FirstName;
        public $LastName;
        public $Nationality;
        public $YearOfBirth;
        public $YearOfDeath;
        public $Details;
        public $ArtistLink;
        
        function getName() {
            return sprintf("%s%s", $this->FirstName . " ", $this->LastName);
        }
        
        function getLifeSpan() {
            return sprintf("%s - %s", $this->YearOfBirth, $this->YearOfDeath);
        }
        
        function getLink() {
            return '<a href="' . $this->ArtistLink . '">' . $this->ArtistLink . '</a>';
        }
        
        function getImage() {
            return '<img src="images/art/artists/medium/' . $this->ArtistID .
                '.jpg" class="img-thumbnail img-responsive" alt="" title=""/>';
        }
    }
    
    function loadArtist($id) {
        try {
            $pdo = new PDO(DBCONNSTR, DBUSER, DBPASS);
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $sql = ARTIST_BY_ID;
            $statement = $pdo->prepare($sql);
            $statement->bindValue(':id', $id);
            $statement->execute();
            
            $artist = $statement->fetchObject('Artist');
            $pdo = null;
            return $artist;
        } catch (PDOException $e) {
            die($e->getMessage());
        }
        
    }

?>