<?php

    // Results will be in $artworks

    require_once('art-config.php');
    
	define('ARTWORK_BY_ID', 'SELECT * FROM artworks WHERE ArtWorkID = :id');
    define('ARTWORK_BY_ARTIST_ID', 'SELECT * FROM artworks WHERE ArtistID = :id;');

    class Artwork {
        public $ArtWorkID;
        public $ArtistID;
        public $ImageFileName;
        public $Title;
        public $Description;
        public $Excerpt;
        public $ArtWorkType;
        public $YearOfWork;
        public $Width;
        public $Height;
        public $Medium;
        public $OriginalHome;
        public $GalleryID;
        public $Cost;
        public $MSRP;
        public $ArtWorkLink;
        public $GoogleLink;
		
		function getCost() {
			return sprintf("$%.2f", $this->Cost);
		}
		
		function getLink() {
			return 'display-art-work.php?id=' . $this->ArtWorkID;
		}
		
		function getAddToCartLink() {
			return 'display-cart.php?id=' . $this->ArtWorkID;
		}
		
		function getImage($subdir, $class = null, $width = null) {
			if ($class === null) {
				$class = "img-thumbnail img-responsive";
			}
			if ($width === null) {
				$width = "";
			} else {
				$width = 'width="' . $width . '"';
			}
			return sprintf('<img src="images/art/works/%s/%s.jpg" class="%s" alt="%s"%s/>',
							$subdir, $this->ImageFileName, $class, $this->Title, $width);
		}
    }
	
	function loadArtwork($id) {
		try {
            $pdo = new PDO(DBCONNSTR, DBUSER, DBPASS);
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $sql = ARTWORK_BY_ID;
            $statement = $pdo->prepare($sql);
            $statement->bindValue(':id', $id);
            $statement->execute();
            
            $artwork = $statement->fetchObject('ArtWork');
            $pdo = null;
            return $artwork;
        } catch (PDOException $e) {
            die($e->getMessage());
        }
	}
    
    function loadArtworks($id) {
        try {
            $pdo = new PDO(DBCONNSTR, DBUSER, DBPASS);
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $sql = ARTWORK_BY_ARTIST_ID;
            $statement = $pdo->prepare($sql);
            $statement->bindValue(':id', $id);
            $statement->execute();
            
            $artworks = array();
            
            while($artwork = $statement->fetchObject('ArtWork')) {
                $artworks[] = $artwork;
            }
            $pdo = null;
            return $artworks;
        } catch (PDOException $e) {
            die($e->getMessage());
        }
    }
    
    function printAllArtworks($artistID) {
        $artworks = loadArtworks($artistID);
        foreach ($artworks as $artwork) {
            printf('<div class="col-md-3">');
            printf('<div class="thumbnail">');
            printf("%s", $artwork->getImage('square-medium'));
            printf('<div class="caption">');
            printf('<a class="btn btn-primary btn-xs" href="%s"><span class="glyphicon glyphicon-info-sign"></span> View</a>', $artwork->getLink());
            printf('<button type="button" class="btn btn-success btn-xs"><span class="glyphicon glyphicon-gift"></span> Wish</button>');
            printf('<a href="%s"><button type="button" class="btn btn-info btn-xs"><span class="glyphicon glyphicon-shopping-cart"></span> Cart</button></a>', $artwork->getAddToCartLink());
            printf('</div>');
            printf('</div>');
            printf("</div>\n");
        }
    }
	
	function addArtWorkToCart($id) {
		if (isset($_COOKIE["cart"])) {
			$artworks = json_decode($_COOKIE["cart"], true);
		} else {
			$artworks = array();
		}
		if (isset($artworks[$id])) {
			$artworks[$id] = $artworks[$id] + 1;
		} else {
			$artworks[$id] = 1;
		}
		setcookie("cart", json_encode($artworks), time() + COOKIE_TIME);
		return $artworks;
	}

?>