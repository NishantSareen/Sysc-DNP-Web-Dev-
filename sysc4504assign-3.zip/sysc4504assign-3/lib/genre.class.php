<?php

require_once('art-config.php');

define('GENRES_BY_ARTWORK_ID',
		'SELECT * FROM Genres
		INNER JOIN ArtworkGenres ON ArtworkGenres.GenreID = Genres.GenreID WHERE ArtworkGenres.ArtworkID = :id;');

class Genre {
	public $GenreID;
	public $GenreName;
	public $Era;
	public $Description;
	public $Link;
	
	function getLink() {
		return sprintf('<a href="%s">%s</a>', $this->Link, $this->GenreName);
	}
}

function loadGenres($artworkId) {
	try {
		$pdo = new PDO(DBCONNSTR, DBUSER, DBPASS);
		$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		$sql = GENRES_BY_ARTWORK_ID;
		$statement = $pdo->prepare($sql);
		$statement->bindValue(':id', $artworkId);
		$statement->execute();
		
		$genres = array();
		
		while($genre = $statement->fetchObject('Genre')) {
			$genres[] = $genre;
		}
		$pdo = null;
		return $genres;
	} catch (PDOException $e) {
		die($e->getMessage());
	}
}

function printAllGenreLinks($genres) {
	$i = 0;
	for (; $i < count($genres) - 1; $i++) {
		printf("%s, ", $genres[$i]->getLink());
	}
	printf("%s", $genres[$i]->getLink());
}

?>