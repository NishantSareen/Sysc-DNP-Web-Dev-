<?php

    define('DBHOST', 'localhost');
    define('DBNAME', 'art');
    define('DBUSER', 'testuser2');
    define('DBPASS', 'mypassword');
    define('DBCONNSTR', 'mysql:host=localhost;dbname=art');
	
	// Cookies will last for 2 hours
	define('COOKIE_TIME', 60 * 60 * 2)

?>