<?php
require_once('lib/art-config.php');
require_once('lib/artist.class.php');
require_once('lib/artwork.class.php');
require_once('lib/gallery.class.php');
require_once('lib/genre.class.php');
require_once('lib/subject.class.php');
$page = $_SERVER['PHP_SELF'];
if ($_SERVER["REQUEST_METHOD"] === "GET") {
	if (isset($_GET["id"]) && $_GET["id"] > 0) {
		$artwork = loadArtwork($_GET["id"]);
	} else {
		$artwork = loadArtwork(1);
	}
		$artist = loadArtist($artwork->ArtistID);
	$gallery = loadGallery($artwork->ArtWorkID);
	$genres = loadGenres($artwork->ArtWorkID);
	$subjects = loadSubjects($artwork->ArtWorkID);
}
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Assignment 3</title>
	    <!-- Bootstrap core CSS  -->    
    <link href="bootstrap3_defaultTheme/dist/css/bootstrap.css" rel="stylesheet"> 
    <!-- Custom styles for this template -->
    <link href="bootstrap3_defaultTheme/theme.css" rel="stylesheet">
	  </head>
  <body>
<?php include 'includes/art-header.inc.php'; ?>
<div class="container">
   <div class="row">
         <div class="col-md-10">
         <h2><?php printf("%s", $artwork->Title) ?></h2>
         <p>By <?php printf('<a href="display-artist.php?id=%s">%s</a>', $artwork->ArtistID, $artist->getName()); ?></p>
         <div class="row">
            <div class="col-md-5">
               <?php printf("%s", $artwork->getImage('medium')); ?>
            </div>
            <div class="col-md-7">
               <p>
			      <?php printf("%s", $artwork->Description); ?>
               </p>
               <p class="price"><?php printf("%s", $artwork->getCost()); ?></p>
               <div class="btn-group btn-group-lg">
                 <button type="button" class="btn btn-default">
                     <a href="#"><span class="glyphicon glyphicon-gift"></span> Add to Wish List</a>  
                 </button>
                 <button type="button" class="btn btn-default">
                  <a href="display-cart.php"><span class="glyphicon glyphicon-shopping-cart"></span> Add to Shopping Cart</a>
                 </button>
               </div>               
               <p>&nbsp;</p>
               <div class="panel panel-default">
                 <div class="panel-heading"><h4>Product Details</h4></div>
                 <table class="table">
                   <tr>
                     <th>Date:</th>
                     <td><?php printf("%s", $artwork->YearOfWork); ?></td>
                   </tr>
                   <tr>
                     <th>Medium:</th>
                     <td><?php printf("%s", $artwork->Medium); ?></td>
                   </tr>  
                   <tr>
                     <th>Dimensions:</th>
                     <td><?php printf("%s cm X %s cm", $artwork->Width, $artwork->Height); ?></td>
                   </tr> 
                   <tr>
                     <th>Home:</th>
                     <td><?php printf("%s", $gallery->getLink()) ?></td>
                   </tr>  
                   <tr>
                     <th>Genres:</th>
                     <td>
					    <?php printAllGenreLinks($genres) ?>
                     </td>
                   </tr> 
                   <tr>
                     <th>Subjects:</th>
                     <td>
					    <?php printAllSubjects($subjects) ?>
                     </td>
                   </tr>     
                 </table>
               </div>                              
                </div>  <!-- end col-md-7 -->
         </div>  <!-- end row (product info) -->
		          <?php include 'includes/art-artist-works.inc.php'; ?>
                    
      </div>  <!-- end col-md-10 (main content) -->
            <div class="col-md-2">   
         <?php include 'includes/art-shopping-cart.inc.php'; ?>
               <?php include 'includes/art-right-nav.inc.php'; ?>
      </div> <!-- end col-md-2 (right navigation) -->           
   </div>  <!-- end main row --> 
</div>  <!-- end container -->
<?php include 'includes/art-footer.inc.php'; ?>
    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="bootstrap-3.0.0/assets/js/jquery.js"></script>
    <script src="bootstrap-3.0.0/dist/js/bootstrap.min.js"></script>    
  </body>
</html>