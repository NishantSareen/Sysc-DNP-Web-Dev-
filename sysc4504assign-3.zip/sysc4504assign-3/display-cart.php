<?php
$page = $_SERVER['PHP_SELF'];
require_once('lib/art-config.php');
require_once('lib/artwork.class.php');
$page = $_SERVER['PHP_SELF'];
if ($_SERVER["REQUEST_METHOD"] === "GET") {
	if (isset($_GET["id"]) && $_GET["id"] > 0) {
		$cart = addArtWorkToCart($_GET["id"]);
	} else if (isset($_GET["reset"]) && $_GET["reset"] === "true") {
		setcookie("cart", json_encode(array()), time() + COOKIE_TIME);
		$cart = array();
	} else {
		$cart = json_decode($_COOKIE["cart"], true);
	}
}
function printCart($cart) {
	if (empty($cart)) {
		printf("<h2>Your cart is empty</h2>");
		return;
	}
	printf('<h2>View Cart</h2><table class="table"><tr><th>Image</th><th>Product</th><th>Quantity</th><th>Price</th><th>Amount</th></tr>');
	
	$total = 0;
	foreach ($cart as $id => $quantity) {
		printf("<tr>");
		$artwork = loadArtwork($id);
		printf("<td>%s</td>", $artwork->getImage("square-thumbs"));
		printf("<td>%s</td>", $artwork->Title);
		printf("<td>%s</td>", $quantity);
		printf("<td>%s</td>", $artwork->getCost());
		$subtotal = $artwork->Cost * $quantity;
		printf("<td>$%.2f</td>", $subtotal);
		$total += $subtotal;
		printf("</tr>");
	}
	printf("<tfoot>");
	printf('<tr class="success"><td colspan="4" align="right">Subtotal</td><td>$%.2f</td></tr>', $total);
	$tax = $total * .1;
	printf('<tr class="active"><td colspan="4" align="right">Tax</td><td>$%.2f</td></tr>', $tax);
	$shipping = 100;
	printf('<tr class=""><td colspan="4" align="right">Shipping</td><td>$%.2f</td></tr>', $shipping);
	printf('<tr class="warning price"><td colspan="4" align="right">Grand Total</td><td>$%.2f</td></tr>', $total + $tax + $shipping);
	printf('<tr><td colspan="5" align="right"><a href="display-cart.php?reset=true"><button type="button" class="btn btn-primary"">Continue Shopping</button></a>');
	printf('<a href="display-cart.php?reset=true"><button type="button" class="btn btn-success">Checkout</button></td></tr></a>');
	printf("</tfoot></table>");
	
}
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Assignment 3</title>
    <!-- Bootstrap core CSS  -->    
    <link href="bootstrap3_defaultTheme/dist/css/bootstrap.css" rel="stylesheet"> 
    <!-- Custom styles for this template -->
    <link href="bootstrap3_defaultTheme/theme.css" rel="stylesheet">
  </head>
  <body>
<?php include 'includes/art-header.inc.php'; ?>
<div class="container">
   <div class="row">
      <div class="col-md-10">
		 <?php printCart($cart); ?>
      </div>  <!-- end col-md-10 (main content) -->
	     </div>  <!-- end main row --> 
 </div>  <!-- end container -->

<?php include 'includes/art-footer.inc.php'; ?>

    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="bootstrap-3.0.0/assets/js/jquery.js"></script>
    <script src="bootstrap-3.0.0/dist/js/bootstrap.min.js"></script>    
  </body>
</html>