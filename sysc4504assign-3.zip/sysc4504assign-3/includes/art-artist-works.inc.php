<?php 

require_once('lib/art-config.php');
require_once('lib/artist.class.php');
require_once('lib/artwork.class.php');

// Check if no artist?

?>

<h3>Art by <?php printf("%s", $artist->getName()); ?></h3>  

<div class="row">

   <?php printAllArtworks($artist->ArtistID); ?>

</div>  <!-- end artist's works row -->