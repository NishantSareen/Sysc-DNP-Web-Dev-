<?php
$page = $_SERVER['PHP_SELF'];
require_once('lib/art-config.php');
require_once('lib/artwork.class.php');
$page = $_SERVER['PHP_SELF'];
$cart = json_decode($_COOKIE["cart"], true);
function printSmallCart($cart) {
	if (empty($cart)) {
		printf("<p>Your cart is empty</p>");
		return;
	}
	
	$subtotal = 0;
	foreach ($cart as $id => $quantity) {
		$artwork = loadArtwork($id);
		$subtotal += $artwork->Cost;
		printf('<div class="media"><a class="pull-left" href="#">');
		printf('%s', $artwork->getImage('tiny', 'media-object', 32));
		printf('</a><div class="media-body"><p class="cartText">');
		printf('<a href="%s">%s</a></p>', $artwork->getLink(), $artwork->Title);
		printf('</div></div>');
	}
	printf('<strong class="cartText">Subtotal: <span class="text-warning">$%.2f</span></strong>', $subtotal);
}
?>

<div class="panel panel-primary">
   <div class="panel-heading">
      <h3 class="panel-title">Cart </h3>
   </div>
   <div class="panel-body"> 
      <?php printSmallCart($cart) ?>
      <div>
      <button type="button" class="btn btn-primary btn-xs"><span class="glyphicon glyphicon-info-sign"></span> Edit</button>
      <button type="button" class="btn btn-primary btn-xs"><span class="glyphicon glyphicon-arrow-right"></span> Checkout</button>
      </div>
   </div>
</div>    